'use strict';

/**
 * @ngdoc overview
 * @name webBuilderApp
 * @description
 * # webBuilderApp
 *
 * Main popup module of the application.
 */   
   angular.module('PopupApp', ['windowsPopup']);

